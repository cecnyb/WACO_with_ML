PACKAGES_FOUND
--------------

List of packages which were found during the CMake run.

List of packages which were found during the CMake run.  Whether a
package has been found is determined using the <NAME>_FOUND variables.
